-- COME 381 Midterm Project - Ödev 1
-- Spor Kulübü veritabanı şeması

CREATE TABLE member (
    member_id integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    full_name varchar(100),
    email varchar(150),
    city varchar(80)
);

CREATE TABLE instructor (
    instructor_id integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    full_name varchar(100),
    specialty varchar(100)
);

CREATE TABLE category (
    category_id integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    category_name varchar(80)
);

CREATE TABLE event (
    event_id integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    title varchar(150),
    start_date date,
    end_date date,
    capacity integer,
    price numeric(10,2),
    status varchar(20),
    category_id integer,
    instructor_id integer,
    CONSTRAINT fk_event_category
        FOREIGN KEY (category_id) REFERENCES category(category_id)
        ON DELETE RESTRICT,
    CONSTRAINT fk_event_instructor
        FOREIGN KEY (instructor_id) REFERENCES instructor(instructor_id)
        ON DELETE RESTRICT
);

CREATE TABLE event_registration (
    registration_id integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    member_id integer,
    event_id integer,
    registered_on date,
    CONSTRAINT fk_registration_member
        FOREIGN KEY (member_id) REFERENCES member(member_id)
        ON DELETE CASCADE,
    CONSTRAINT fk_registration_event
        FOREIGN KEY (event_id) REFERENCES event(event_id)
        ON DELETE CASCADE
);

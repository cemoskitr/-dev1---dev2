# Ödev 2 - Çalıştırma Notları

## Çalıştırma sırası

```bash
psql -d come381 -f sql/schema.sql
psql -d come381 -f week-05/constraints.sql
psql -d come381 -f week-05/violations.sql
psql -d come381 -f week-05/seed.sql
psql -d come381 -f week-05/algebra.sql
```

Windows'ta gerekiyorsa komutlara `-U postgres` eklenebilir.

`violations.sql` tabloları `TRUNCATE ... RESTART IDENTITY CASCADE` ile temizleyerek başladığı için `seed.sql` daha sonra çalıştırılmalıdır.

## NULL testi

`chk_event_price` constraint'i tek başına `NULL` değeri engellemez. PostgreSQL'de `CHECK (price >= 0)` ifadesi `price` NULL olduğunda FALSE değil UNKNOWN üretir ve satır kabul edilir. Bu nedenle `NOT NULL` ile `CHECK` farklı amaçlara hizmet eder.

## Beklenmedik sonuç / öğrenilen nokta

D6 division sorgusunda sadece kayıt sayısını saymak yerine "eksik Fitness etkinliği var mı?" mantığını kullandım. Böylece bir üyenin spor dışı etkinliklere kayıtlı olması veya aynı etkinliğin tekrar sayılması division sonucunu yanlış etkilemez.

`violations_output.txt` dosyası psql tarafından üretilmelidir; bu dosyada elle düzenleme yapılmamalıdır. Üretmek için:

```bash
psql -d come381 -f week-05/violations.sql > week-05/violations_output.txt 2>&1
```

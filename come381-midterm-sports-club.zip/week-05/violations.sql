\set VERBOSITY verbose

-- Test ortamını her çalıştırmada aynı hale getir.
TRUNCATE TABLE event_registration, event, category, instructor, member
RESTART IDENTITY CASCADE;

INSERT INTO member (full_name, email, city) VALUES
('Ali Yılmaz', 'ali@example.com', 'Istanbul'),
('Ayşe Demir', 'ayse@example.com', 'Istanbul'),
('Can Kaya', 'can@example.com', 'Ankara');

INSERT INTO instructor (full_name, specialty) VALUES
('Mert Akın', 'Strength'),
('Zeynep Koç', 'Yoga'),
('Burak Eren', 'Aquatics');

INSERT INTO category (category_name) VALUES
('Fitness'),
('Wellness'),
('Aquatics');

INSERT INTO event
(title, start_date, end_date, capacity, price, status, category_id, instructor_id)
VALUES
('Strength Basics', '2026-11-10', '2026-11-10', 30, 100.00, 'active', 1, 1);

-- T01 | member.full_name NOT NULL | Beklenen: 23502
INSERT INTO member (full_name, email, city)
VALUES (NULL, 't01@example.com', 'Istanbul');

-- T02 | member.email NOT NULL | Beklenen: 23502
INSERT INTO member (full_name, email, city)
VALUES ('Test Member', NULL, 'Istanbul');

-- T03 | instructor.full_name NOT NULL | Beklenen: 23502
INSERT INTO instructor (full_name, specialty)
VALUES (NULL, 'Test');

-- T04 | category.category_name NOT NULL | Beklenen: 23502
INSERT INTO category (category_name)
VALUES (NULL);

-- T05 | event.title NOT NULL | Beklenen: 23502
INSERT INTO event
(title, start_date, end_date, capacity, price, status, category_id, instructor_id)
VALUES (NULL, '2026-11-10', '2026-11-10', 20, 50.00, 'active', 1, 1);

-- T06 | event.start_date NOT NULL | Beklenen: 23502
INSERT INTO event
(title, start_date, end_date, capacity, price, status, category_id, instructor_id)
VALUES ('Null Start', NULL, '2026-11-10', 20, 50.00, 'active', 1, 1);

-- T07 | event.end_date NOT NULL | Beklenen: 23502
INSERT INTO event
(title, start_date, end_date, capacity, price, status, category_id, instructor_id)
VALUES ('Null End', '2026-11-10', NULL, 20, 50.00, 'active', 1, 1);

-- T08 | event.capacity NOT NULL | Beklenen: 23502
INSERT INTO event
(title, start_date, end_date, capacity, price, status, category_id, instructor_id)
VALUES ('Null Capacity', '2026-11-10', '2026-11-10', NULL, 50.00, 'active', 1, 1);

-- T09 | event.status NOT NULL | Beklenen: 23502
INSERT INTO event
(title, start_date, end_date, capacity, price, status, category_id, instructor_id)
VALUES ('Null Status', '2026-11-10', '2026-11-10', 20, 50.00, NULL, 1, 1);

-- T10 | event.category_id NOT NULL | Beklenen: 23502
INSERT INTO event
(title, start_date, end_date, capacity, price, status, category_id, instructor_id)
VALUES ('Null Category', '2026-11-10', '2026-11-10', 20, 50.00, 'active', NULL, 1);

-- T11 | event.instructor_id NOT NULL | Beklenen: 23502
INSERT INTO event
(title, start_date, end_date, capacity, price, status, category_id, instructor_id)
VALUES ('Null Instructor', '2026-11-10', '2026-11-10', 20, 50.00, 'active', 1, NULL);

-- T12 | uq_member_email | Beklenen: 23505
INSERT INTO member (full_name, email, city)
VALUES ('Duplicate Email', 'ali@example.com', 'Izmir');

-- T13 | uq_category_name | Beklenen: 23505
INSERT INTO category (category_name)
VALUES ('Fitness');

-- T14 | uq_registration_member_event | Beklenen: 23505
INSERT INTO event_registration (member_id, event_id, registered_on)
VALUES (1, 1, '2026-11-01');
INSERT INTO event_registration (member_id, event_id, registered_on)
VALUES (1, 1, '2026-11-02');

-- T15 | chk_event_capacity | Beklenen: 23514
INSERT INTO event
(title, start_date, end_date, capacity, price, status, category_id, instructor_id)
VALUES ('Bad Capacity', '2026-11-10', '2026-11-10', 0, 50.00, 'active', 1, 1);

-- T16 | chk_event_status | Beklenen: 23514
INSERT INTO event
(title, start_date, end_date, capacity, price, status, category_id, instructor_id)
VALUES ('Bad Status', '2026-11-10', '2026-11-10', 20, 50.00, 'draft', 1, 1);

-- T17 | chk_event_date_order | Beklenen: 23514
INSERT INTO event
(title, start_date, end_date, capacity, price, status, category_id, instructor_id)
VALUES ('Bad Dates', '2026-11-12', '2026-11-10', 20, 50.00, 'active', 1, 1);

-- T18 | chk_event_price | Beklenen: 23514
INSERT INTO event
(title, start_date, end_date, capacity, price, status, category_id, instructor_id)
VALUES ('Bad Price', '2026-11-10', '2026-11-10', 20, -1.00, 'active', 1, 1);

-- T19 | fk_registration_member | Beklenen: 23503
INSERT INTO event_registration (member_id, event_id, registered_on)
VALUES (999, 1, '2026-11-03');

-- T20 | fk_registration_event | Beklenen: 23503
INSERT INTO event_registration (member_id, event_id, registered_on)
VALUES (1, 999, '2026-11-03');

-- T21 | FK DELETE yönü | Beklenen: 23503
DELETE FROM category WHERE category_id = 1;

-- T22 | FK DELETE yönü | Beklenen: 23503
DELETE FROM instructor WHERE instructor_id = 1;

-- T23 | Sınır testi capacity=1 | Beklenen: OK
INSERT INTO event
(title, start_date, end_date, capacity, price, status, category_id, instructor_id)
VALUES ('Boundary Capacity', '2026-11-11', '2026-11-11', 1, 0.00, 'closed', 1, 1);

-- T24 | Sınır testi end_date=start_date | Beklenen: OK
INSERT INTO event
(title, start_date, end_date, capacity, price, status, category_id, instructor_id)
VALUES ('Boundary Date', '2026-11-12', '2026-11-12', 1, 0.00, 'suspended', 1, 1);

-- T25 | NULL + CHECK column without NOT NULL | Beklenen: OK
-- PostgreSQL CHECK ifadesi NULL olduğunda FALSE üretmez; dolayısıyla satır kabul edilir.
-- Bu örnek, CHECK'in NOT NULL yerine geçmediğini gösterir.
ALTER TABLE event DROP CONSTRAINT chk_event_price;
INSERT INTO event
(title, start_date, end_date, capacity, price, status, category_id, instructor_id)
VALUES ('Null Price Check Test', '2026-11-13', '2026-11-13', 1, NULL, 'active', 1, 1);
ALTER TABLE event
    ADD CONSTRAINT chk_event_price CHECK (price >= 0);

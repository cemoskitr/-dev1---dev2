-- COME 381 Midterm Project - Ödev 2 Bölüm D
-- seed.sql çalıştırıldıktan sonra çalıştırılır.

-- D1: Kapasitesi 50'den büyük etkinliklerin adları.
-- Cebir: π title ( σ capacity > 50 (event) )
SELECT title
FROM event
WHERE capacity > 50;

-- D2: Her kaydın üye adı ve etkinlik adı.
-- Cebir: π full_name, title ( member ⋈ event_registration ⋈ event )
SELECT m.full_name, e.title
FROM member AS m
JOIN event_registration AS r ON r.member_id = m.member_id
JOIN event AS e ON e.event_id = r.event_id
ORDER BY m.full_name, e.title;

-- D3: Fitness veya Aquatics etkinliğine katılmış üyeler.
-- Cebir: FitnessMembers ∪ AquaticsMembers
SELECT m.member_id, m.full_name
FROM member AS m
JOIN event_registration AS r ON r.member_id = m.member_id
JOIN event AS e ON e.event_id = r.event_id
JOIN category AS c ON c.category_id = e.category_id
WHERE c.category_name = 'Fitness'
UNION
SELECT m.member_id, m.full_name
FROM member AS m
JOIN event_registration AS r ON r.member_id = m.member_id
JOIN event AS e ON e.event_id = r.event_id
JOIN category AS c ON c.category_id = e.category_id
WHERE c.category_name = 'Aquatics'
ORDER BY member_id;

-- D4: Hiçbir etkinliğe kaydolmamış üyeler - EXCEPT.
-- Cebir: π member_id, full_name(member) − π member_id, full_name(member ⋈ registration)
SELECT member_id, full_name
FROM member
EXCEPT
SELECT m.member_id, m.full_name
FROM member AS m
JOIN event_registration AS r ON r.member_id = m.member_id
ORDER BY member_id;

-- D4: Aynı soru - NOT EXISTS.
SELECT m.member_id, m.full_name
FROM member AS m
WHERE NOT EXISTS (
    SELECT 1
    FROM event_registration AS r
    WHERE r.member_id = m.member_id
)
ORDER BY m.member_id;

-- D5: Aynı şehirde yaşayan farklı üye çiftleri.
-- Cebir: ρ(m1)(member) ⋈ ρ(m2)(member), koşul m1.city=m2.city ∧ m1.id<m2.id
SELECT
    m1.full_name AS member_1,
    m2.full_name AS member_2,
    m1.city
FROM member AS m1
JOIN member AS m2
    ON m1.city = m2.city
   AND m1.member_id < m2.member_id
ORDER BY m1.city, m1.member_id, m2.member_id;

-- D6: Fitness kategorisindeki TÜM etkinliklere katılmış üyeler.
-- Division: R(member_id, event_id) ÷ S(Fitness event_id)
-- NOT EXISTS ile "eksik etkinlik var mı?" mantığı kullanılır.
SELECT m.member_id, m.full_name
FROM member AS m
WHERE NOT EXISTS (
    SELECT 1
    FROM event AS e
    JOIN category AS c ON c.category_id = e.category_id
    WHERE c.category_name = 'Fitness'
      AND NOT EXISTS (
          SELECT 1
          FROM event_registration AS r
          WHERE r.member_id = m.member_id
            AND r.event_id = e.event_id
      )
)
ORDER BY m.member_id;

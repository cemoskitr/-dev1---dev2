# ON DELETE Politikaları

| Foreign key | Ebeveyn → çocuk | Seçim | Neden | Diğer seçenek neden olmadı |
|---|---|---|---|---|
| `fk_event_category` | category → event | `RESTRICT` | Kategoriye bağlı etkinlikler varken kategoriyi silmek veri bütünlüğünü bozabilir. | `CASCADE` bir kategoriyi silerken ona bağlı etkinlikleri de silebilirdi. |
| `fk_event_instructor` | instructor → event | `RESTRICT` | Bir eğitmenin verdiği etkinliklerin geçmişi korunmalıdır. | `CASCADE` eğitmeni silerken etkinlikleri de silerdi. |
| `fk_registration_member` | member → event_registration | `CASCADE` | Üye silindiğinde üyelik kayıtlarının anlamı kalmaz. | `RESTRICT` üyeyi silmeyi gereksiz yere zorlaştırırdı. |
| `fk_registration_event` | event → event_registration | `CASCADE` | Etkinlik silindiğinde ona ait kayıtların da silinmesi doğaldır. | `RESTRICT` artık var olmayan etkinliğin kayıtlarını bırakmaya zorlayabilirdi. |

## CASCADE kanıtı

Örneğin bir üye silindiğinde o üyeye ait `event_registration` satırlarının da silindiği kontrol edilir:

```sql
SELECT count(*) AS member_count
FROM member
WHERE member_id = 1;

SELECT count(*) AS registration_count
FROM event_registration
WHERE member_id = 1;

DELETE FROM member
WHERE member_id = 1;

SELECT count(*) AS member_count
FROM member
WHERE member_id = 1;

SELECT count(*) AS registration_count
FROM event_registration
WHERE member_id = 1;
```

Beklenen mantık: ilk üye sayısı `1`, silme sonrasında `0`; üyenin kayıt sayısı ise silme sonrasında `0` olur.

## RESTRICT ve NO ACTION farkı

`RESTRICT`, bağlı kayıt varken ebeveyn satırının silinmesini hemen engeller. `NO ACTION` da ihlali engeller ancak PostgreSQL'de constraint'in zamanlamasına bağlı olarak kontrolün transaction sonunda yapılabilmesine izin verebilir; bu nedenle burada açık ve erken davranış için `RESTRICT` tercih edilmiştir.

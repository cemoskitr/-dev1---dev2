-- COME 381 Midterm Project - Ödev 2 Bölüm D
-- Önce schema.sql ve constraints.sql çalıştırılmalıdır.

TRUNCATE TABLE event_registration, event, category, instructor, member
RESTART IDENTITY CASCADE;

INSERT INTO member (full_name, email, city) VALUES
('Ali Yılmaz', 'ali@example.com', 'Istanbul'),
('Ayşe Demir', 'ayse@example.com', 'Istanbul'),
('Can Kaya', 'can@example.com', 'Ankara'),
('Deniz Şahin', 'deniz@example.com', 'Izmir'),
('Ece Arslan', 'ece@example.com', 'Ankara'),
('Emre Çelik', 'emre@example.com', 'Bursa'),
('Fırat Aydın', 'firat@example.com', 'Bursa'),
('Gizem Öz', 'gizem@example.com', 'Izmir');

INSERT INTO instructor (full_name, specialty) VALUES
('Mert Akın', 'Strength'),
('Zeynep Koç', 'Yoga'),
('Burak Eren', 'Aquatics'),
('Selin Tunç', 'Cardio'),
('Okan Yıldız', 'Mobility');

INSERT INTO category (category_name) VALUES
('Fitness'),
('Wellness'),
('Aquatics'),
('Outdoor');

INSERT INTO event
(title, start_date, end_date, capacity, price, status, category_id, instructor_id)
VALUES
('Strength Basics', '2026-11-10', '2026-11-10', 30, 100.00, 'active', 1, 1),
('HIIT Challenge', '2026-11-12', '2026-11-12', 60, 120.00, 'active', 1, 4),
('Functional Training', '2026-11-15', '2026-11-15', 40, 90.00, 'active', 1, 1),
('Yoga Flow', '2026-11-11', '2026-11-11', 25, 80.00, 'active', 2, 2),
('Meditation Workshop', '2026-11-14', '2026-11-14', 20, 50.00, 'closed', 2, 2),
('Swimming Basics', '2026-11-13', '2026-11-13', 35, 110.00, 'active', 3, 3),
('Aqua Aerobics', '2026-11-16', '2026-11-16', 45, 95.00, 'active', 3, 3),
('City Run', '2026-11-20', '2026-11-20', 100, 70.00, 'active', 4, 5);

INSERT INTO event_registration (member_id, event_id, registered_on) VALUES
(1, 1, '2026-11-01'),
(1, 2, '2026-11-01'),
(1, 3, '2026-11-02'),
(1, 6, '2026-11-02'),
(2, 1, '2026-11-01'),
(2, 2, '2026-11-02'),
(2, 4, '2026-11-02'),
(3, 1, '2026-11-03'),
(3, 6, '2026-11-03'),
(4, 4, '2026-11-03'),
(4, 7, '2026-11-03'),
(5, 2, '2026-11-04'),
(5, 3, '2026-11-04'),
(6, 4, '2026-11-04'),
(6, 8, '2026-11-04'),
(7, 6, '2026-11-05'),
(7, 7, '2026-11-05');
-- Member 8 intentionally has no registration for D4.
-- Member 2 is the "almost" D6 candidate: she joined only 2 of 3 Fitness events.

-- COME 381 Midterm Project - Ödev 2 Bölüm A
-- schema.sql çalıştırıldıktan sonra bu dosya çalıştırılır.

-- Üyenin adı boş bırakılamaz.
ALTER TABLE member
    ALTER COLUMN full_name SET NOT NULL;

-- Üyenin e-posta adresi boş bırakılamaz.
ALTER TABLE member
    ALTER COLUMN email SET NOT NULL;

-- Eğitmenin adı boş bırakılamaz.
ALTER TABLE instructor
    ALTER COLUMN full_name SET NOT NULL;

-- Kategori adı boş bırakılamaz.
ALTER TABLE category
    ALTER COLUMN category_name SET NOT NULL;

-- Etkinlik başlığı boş bırakılamaz.
ALTER TABLE event
    ALTER COLUMN title SET NOT NULL;

-- Etkinliğin başlangıç tarihi boş bırakılamaz.
ALTER TABLE event
    ALTER COLUMN start_date SET NOT NULL;

-- Etkinliğin bitiş tarihi boş bırakılamaz.
ALTER TABLE event
    ALTER COLUMN end_date SET NOT NULL;

-- Etkinlik kapasitesi boş bırakılamaz.
ALTER TABLE event
    ALTER COLUMN capacity SET NOT NULL;

-- Etkinlik durumu boş bırakılamaz.
ALTER TABLE event
    ALTER COLUMN status SET NOT NULL;

-- Etkinliğin kategorisi boş bırakılamaz.
ALTER TABLE event
    ALTER COLUMN category_id SET NOT NULL;

-- Etkinliğin eğitmeni boş bırakılamaz.
ALTER TABLE event
    ALTER COLUMN instructor_id SET NOT NULL;

-- Bir üyenin e-posta adresi tekil olmalıdır.
ALTER TABLE member
    ADD CONSTRAINT uq_member_email UNIQUE (email);

-- Aynı kategori adı ikinci kez kullanılamaz.
ALTER TABLE category
    ADD CONSTRAINT uq_category_name UNIQUE (category_name);

-- Aynı üye aynı etkinliğe iki kez kayıt olamaz.
ALTER TABLE event_registration
    ADD CONSTRAINT uq_registration_member_event UNIQUE (member_id, event_id);

-- Bir etkinliğin kapasitesi pozitif olmalıdır.
ALTER TABLE event
    ADD CONSTRAINT chk_event_capacity CHECK (capacity > 0);

-- Etkinlik durumu yalnızca izin verilen değerlerden biri olabilir.
ALTER TABLE event
    ADD CONSTRAINT chk_event_status CHECK (status IN ('active', 'suspended', 'closed'));

-- Bir etkinlik başladığı günden önce bitemez.
ALTER TABLE event
    ADD CONSTRAINT chk_event_date_order CHECK (end_date >= start_date);

-- Etkinlik ücreti negatif olamaz.
ALTER TABLE event
    ADD CONSTRAINT chk_event_price CHECK (price >= 0);

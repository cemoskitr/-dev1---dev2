# İlişkisel Cebir ve Hesap

## Veri seti

`seed.sql` her tabloya örnek veri ekler. D4'ün boş dönmemesi için Gizem Öz'ün hiç kaydı yoktur. D6'nın "neredeyse" adayını test etmek için Ayşe Demir üç Fitness etkinliğinden yalnızca ikisine kayıtlıdır.

## D1 — Selection + Projection

**Soru:** Kapasitesi 50'den büyük etkinliklerin adları nelerdir?

**İlişkisel cebir:**

`π title ( σ capacity > 50 (event) )`

**SQL:** `algebra.sql` içindeki D1.

**Beklenen sonuç:**

| title |
|---|
| HIIT Challenge |
| City Run |

**DISTINCT:** Gerekli değil. `event_id` her satırı tekil yaptığı için farklı etkinliklerin `title` değerleri tekrar etmediği veri setinde sonuç zaten tektir; burada cebirsel olarak projection küme mantığı taşısa da SQL'deki tekrar problemi bu veriyle oluşmaz.

## D2 — Join

**Soru:** Her kayıt için üye adı ve etkinlik adı nedir?

**İlişkisel cebir:**

`π full_name, title ( member ⋈ event_registration ⋈ event )`

**SQL:** `algebra.sql` içindeki D2.

**Beklenen sonuçtan örnekler:** Ali Yılmaz — Strength Basics, Ali Yılmaz — HIIT Challenge, Ayşe Demir — Strength Basics.

**DISTINCT:** Gerekli değil; her `event_registration` satırı tek bir üye-etkinlik çiftini temsil eder ve çok sütunlu UNIQUE constraint aynı çifti tekrar ettirmez.

## D3 — Union

**Soru:** Fitness veya Aquatics etkinliğine katılmış üyeler kimlerdir?

**İlişkisel cebir:**

`FitnessMembers ∪ AquaticsMembers`

**SQL:** `algebra.sql` içindeki D3.

**Beklenen sonuç:**

| member_id | full_name |
|---:|---|
| 1 | Ali Yılmaz |
| 2 | Ayşe Demir |
| 3 | Can Kaya |
| 4 | Deniz Şahin |
| 5 | Ece Arslan |
| 7 | Fırat Aydın |

**DISTINCT:** SQL `UNION` tekrarları otomatik kaldırdığı için ayrıca `DISTINCT` gerekmez.

## D4 — Difference

**Soru:** Hiçbir etkinliğe kaydolmamış üyeler kimlerdir?

**İlişkisel cebir:**

`π member_id, full_name(member) − π member_id, full_name(member ⋈ event_registration)`

**SQL:** `algebra.sql` içinde hem `EXCEPT` hem `NOT EXISTS` ile yazılmıştır.

**Beklenen sonuç:**

| member_id | full_name |
|---:|---|
| 8 | Gizem Öz |

**DISTINCT:** `EXCEPT` küme işlemi olduğu için tekrarları kaldırır. `NOT EXISTS` ise üye tablosundaki tekil `member_id` üzerinden çalıştığı için ayrıca `DISTINCT` gerekmez.

## D5 — Rename + Self Join

**Soru:** Aynı şehirde yaşayan farklı üye çiftleri hangileridir?

**İlişkisel cebir:**

`ρ(m1)(member) ⋈ ρ(m2)(member), m1.city = m2.city ∧ m1.member_id < m2.member_id`

**SQL:** `algebra.sql` içindeki D5.

**Beklenen sonuç:**

| member_1 | member_2 | city |
|---|---|---|
| Ali Yılmaz | Ayşe Demir | Istanbul |
| Can Kaya | Ece Arslan | Ankara |
| Deniz Şahin | Gizem Öz | Izmir |
| Emre Çelik | Fırat Aydın | Bursa |

**DISTINCT:** Gerekli değil; `m1.member_id < m2.member_id` koşulu aynı çiftin ters sırayla ikinci kez üretilmesini engeller.

## D6 — Division

**Soru:** Fitness kategorisindeki tüm etkinliklere katılmış üyeler kimlerdir?

**İlişkisel cebir:**

`R(member_id, event_id) ÷ S(event_id)`

Burada `R`, üye-etkinlik kayıtları; `S`, Fitness kategorisindeki etkinliklerdir.

**SQL:** `algebra.sql` içindeki D6.

**Beklenen sonuç:**

| member_id | full_name |
|---:|---|
| 1 | Ali Yılmaz |

Ayşe Demir iki Fitness etkinliğine katıldığı için elenir; üç Fitness etkinliğinin tamamına katılmamıştır.

SQL'de doğrudan division operatörü bulunmadığı için iç içe `NOT EXISTS` kullanıldı. Mantık, "üye için katılmadığı bir Fitness etkinliği var mı?" sorusunu aramak ve böyle bir etkinlik yoksa üyeyi seçmektir. Bu yaklaşım, division'ın "hepsini karşılıyor" anlamını doğrudan ifade eder.

**DISTINCT:** Gerekli değil; dış sorgu `member` tablosundan tek satır üretir.

## Tuple Relational Calculus

D1 sorusunun tuple relational calculus gösterimi:

`{ t.title | event(t) ∧ t.capacity > 50 }`

Bu ifade, `event` ilişkisine ait ve kapasitesi 50'den büyük olan tuple'ların `title` alanlarını seçer.

# AI Log

## Ödev 1

Yapay zekâ, senaryo için ER modeli ve PostgreSQL şemasının tasarlanmasında kullanıldı. M:N ilişki için `event_registration` ara tablosunun seçilmesi ve Mermaid ER diyagramının hazırlanmasında yardım alındı.

## Ödev 2

### D6 - Division promptu

Kullandığım prompt:

> "PostgreSQL'de bir spor kulübü veritabanında Fitness kategorisindeki tüm etkinliklere katılmış üyeleri bulmak için ilişkisel division mantığını SQL ile yaz. `member`, `event`, `category` ve `event_registration` tablolarını kullan. SQL'de division operatörü olmadığı için uygun bir yöntem seç ve sorgunun neden division yaptığını açıkla."

### Sonuç ve kontrol

D6 için `NOT EXISTS` ile iç içe bir sorgu kullanıldı. Sorgunun mantığı, her üye için katılmadığı bir Fitness etkinliği bulunup bulunmadığını kontrol etmektir; eksik etkinlik yoksa üye sonuçta kalır.

Kontrol verisinde Ali Yılmaz üç Fitness etkinliğinin tamamına katıldığı için sonuçta kalırken Ayşe Demir yalnızca iki Fitness etkinliğine katıldığı için elenir. Ayrıca spor dışı etkinliklere yapılan kayıtlar sorgunun sonucunu etkilemez.

Ödevin diğer bölümlerinde de yapay zekâ; SQL dosyalarının taslağını oluşturmak, ilişkisel cebir ifadelerini yazmak ve test senaryolarını düzenlemek için kullanıldı. Sonuçların kendi şeması ve `seed.sql` verisi üzerinde kontrol edilmesi gerekir.

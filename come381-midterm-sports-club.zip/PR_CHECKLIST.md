## Ödev 1
- [ ] docs/er.md GitHub'da çizim olarak görünüyor
- [ ] sql/schema.sql temiz bir veritabanında hatasız çalışıyor
- [ ] README'de senaryo ve bir tasarım kararı var

## Ödev 2
- [ ] constraints.sql hatasız çalışıyor, her constraint'in adı ve yorumu var
- [ ] violations.sql en az 10 test, 2 sınır testi, 1 NULL testi içeriyor
- [ ] violations_output.txt psql'den alındı, elle düzenlenmedi
- [ ] on_delete.md her foreign key'i kapsıyor, en az iki farklı politika var
- [ ] algebra.md'de altı soru, bir hesap ifadesi ve DISTINCT notları var
- [ ] AI_LOG.md'de "Ödev 2" başlığı ve D6 denemesi var

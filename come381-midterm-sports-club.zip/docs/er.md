# ER Diyagramı

```mermaid
erDiagram
    MEMBER ||--o{ EVENT_REGISTRATION : "registers"
    EVENT ||--o{ EVENT_REGISTRATION : "has"
    CATEGORY ||--o{ EVENT : "contains"
    INSTRUCTOR ||--o{ EVENT : "leads"

    MEMBER {
        int member_id PK
        string full_name
        string email
        string city
    }

    INSTRUCTOR {
        int instructor_id PK
        string full_name
        string specialty
    }

    CATEGORY {
        int category_id PK
        string category_name
    }

    EVENT {
        int event_id PK
        string title
        date start_date
        date end_date
        int capacity
        numeric price
        string status
        int category_id FK
        int instructor_id FK
    }

    EVENT_REGISTRATION {
        int registration_id PK
        int member_id FK
        int event_id FK
        date registered_on
    }
```

## Tasarım notu

`MEMBER` ile `EVENT` arasında çoktan-çoğa (M:N) ilişki vardır. Bu ilişkiyi `EVENT_REGISTRATION` ara tablosu ile modelledim; böylece bir üye birçok etkinliğe, bir etkinlik de birçok üyeye sahip olabilir.

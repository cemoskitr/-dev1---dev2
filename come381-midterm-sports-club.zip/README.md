# COME 381 Midterm Project

Bu projede bir spor kulübünün üyeleri, eğitmenleri, etkinlikleri ve etkinlik kategorileri modellenmiştir. Üyeler etkinliklere kayıt olabilir ve bu ilişki `event_registration` ara tablosu üzerinden M:N olarak kurulmuştur. Bir etkinlik bir kategoriye ve bir eğitmene bağlıdır. Tasarım kararı olarak üyeler ile etkinlikler arasındaki M:N ilişkiyi ayrı bir ara tabloya ayırdım; böylece aynı üyenin aynı etkinliğe birden fazla kayıt olması daha sonra `UNIQUE` constraint'i ile engellenebilir.
